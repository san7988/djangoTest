from django.apps import AppConfig


class MyrestaurantsConfig(AppConfig):
    name = 'myrestaurants'
